// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// Generator: TemplateGenerator
// **************************************************************************

// ignore_for_file: cancel_subscriptions,constant_identifier_names,duplicate_import,non_constant_identifier_names,library_prefixes,UNUSED_IMPORT,UNUSED_SHOWN_NAME
import 'directive_change_detector.dart';
export 'directive_change_detector.dart';
import 'dart:html';
import 'dart:js_util' as js_util;
import '../metadata/lifecycle_hooks.dart';
import 'change_detection_util.dart';
// Required for initReflector().
import '../metadata/lifecycle_hooks.template.dart' as _ref0;
import 'change_detection_util.template.dart' as _ref1;

var _visited = false;
void initReflector() {
  if (_visited) {
    return;
  }
  _visited = true;
  _ref0.initReflector();
  _ref1.initReflector();
}

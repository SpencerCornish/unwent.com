// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// Generator: TemplateGenerator
// **************************************************************************

// ignore_for_file: cancel_subscriptions,constant_identifier_names,duplicate_import,non_constant_identifier_names,library_prefixes,UNUSED_IMPORT,UNUSED_SHOWN_NAME
import 'di.dart';
export 'di.dart';
// Required for initReflector().
import '../di/injector/injector.template.dart' as _ref0;
import '../di/injector/reflective.template.dart' as _ref1;
import 'di/decorators.template.dart' as _ref2;
import 'di/opaque_token.template.dart' as _ref3;
import 'di/provider.template.dart' as _ref4;

var _visited = false;
void initReflector() {
  if (_visited) {
    return;
  }
  _visited = true;
  _ref0.initReflector();
  _ref1.initReflector();
  _ref2.initReflector();
  _ref3.initReflector();
  _ref4.initReflector();
}

// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// Generator: TemplateGenerator
// **************************************************************************

// ignore_for_file: cancel_subscriptions,constant_identifier_names,duplicate_import,non_constant_identifier_names,library_prefixes,UNUSED_IMPORT,UNUSED_SHOWN_NAME
import 'ng_zone.dart';
export 'ng_zone.dart';
import 'dart:async';
import 'package:stack_trace/stack_trace.dart';
// No initReflector() linking required.

// No initReflector() needed.
void initReflector() {}

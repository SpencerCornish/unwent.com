This is a transitional folder of [AngularDart DI 1.5][DI], where interfaces
and libraries that are cleaned up as part of this effort are being moved to
`src/di` (out of `src/core/di`).

[DI]: https://github.com/dart-lang/angular/projects/4

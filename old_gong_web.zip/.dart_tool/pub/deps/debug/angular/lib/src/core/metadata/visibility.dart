/// Restricts where a directive or provider is visible for injection.
enum Visibility {
  /// Can't be injected anywhere.
  none,
}

// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// Generator: TemplateGenerator
// **************************************************************************

// ignore_for_file: cancel_subscriptions,constant_identifier_names,duplicate_import,non_constant_identifier_names,library_prefixes,UNUSED_IMPORT,UNUSED_SHOWN_NAME
import 'template_processor.dart';
export 'template_processor.dart';
import 'dart:async';
import 'package:angular/src/compiler/offline_compiler.dart';
import 'package:angular/src/source_gen/common/logging.dart';
import 'package:angular/src/source_gen/common/ng_compiler.dart';
import 'package:angular_compiler/angular_compiler.dart';
import 'package:analyzer/dart/element/element.dart';
import 'package:build/build.dart';
import 'find_components.dart';
import 'template_compiler_outputs.dart';
// Required for initReflector().
import 'find_components.template.dart' as _ref0;
import 'package:angular/src/compiler/offline_compiler.template.dart' as _ref1;
import 'package:angular/src/source_gen/common/logging.template.dart' as _ref2;
import 'package:angular/src/source_gen/common/ng_compiler.template.dart' as _ref3;
import 'template_compiler_outputs.template.dart' as _ref4;

var _visited = false;
void initReflector() {
  if (_visited) {
    return;
  }
  _visited = true;
  _ref0.initReflector();
  _ref1.initReflector();
  _ref2.initReflector();
  _ref3.initReflector();
  _ref4.initReflector();
}

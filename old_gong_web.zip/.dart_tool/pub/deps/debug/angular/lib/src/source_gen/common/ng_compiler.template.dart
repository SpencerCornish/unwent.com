// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// Generator: TemplateGenerator
// **************************************************************************

// ignore_for_file: cancel_subscriptions,constant_identifier_names,duplicate_import,non_constant_identifier_names,library_prefixes,UNUSED_IMPORT,UNUSED_SHOWN_NAME
import 'ng_compiler.dart';
export 'ng_compiler.dart';
import 'package:build/build.dart' hide AssetReader;
import 'package:angular_compiler/angular_compiler.dart';
import 'package:angular/src/compiler/directive_normalizer.dart';
import 'package:angular/src/compiler/expression_parser/lexer.dart' as ng;
import 'package:angular/src/compiler/expression_parser/parser.dart' as ng;
import 'package:angular/src/compiler/html_parser.dart';
import 'package:angular/src/compiler/offline_compiler.dart';
import 'package:angular/src/compiler/output/dart_emitter.dart';
import 'package:angular/src/compiler/schema/dom_element_schema_registry.dart';
import 'package:angular/src/compiler/style_compiler.dart';
import 'package:angular/src/compiler/template_parser.dart';
import 'package:angular/src/compiler/view_compiler/view_compiler.dart';
// Required for initReflector().
import 'package:angular/src/compiler/directive_normalizer.template.dart' as _ref0;
import 'package:angular/src/compiler/expression_parser/lexer.template.dart' as _ref1;
import 'package:angular/src/compiler/expression_parser/parser.template.dart' as _ref2;
import 'package:angular/src/compiler/html_parser.template.dart' as _ref3;
import 'package:angular/src/compiler/offline_compiler.template.dart' as _ref4;
import 'package:angular/src/compiler/output/dart_emitter.template.dart' as _ref5;
import 'package:angular/src/compiler/schema/dom_element_schema_registry.template.dart' as _ref6;
import 'package:angular/src/compiler/style_compiler.template.dart' as _ref7;
import 'package:angular/src/compiler/template_parser.template.dart' as _ref8;
import 'package:angular/src/compiler/view_compiler/view_compiler.template.dart' as _ref9;

var _visited = false;
void initReflector() {
  if (_visited) {
    return;
  }
  _visited = true;
  _ref0.initReflector();
  _ref1.initReflector();
  _ref2.initReflector();
  _ref3.initReflector();
  _ref4.initReflector();
  _ref5.initReflector();
  _ref6.initReflector();
  _ref7.initReflector();
  _ref8.initReflector();
  _ref9.initReflector();
}

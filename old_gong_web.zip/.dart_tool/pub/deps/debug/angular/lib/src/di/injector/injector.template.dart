// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// Generator: TemplateGenerator
// **************************************************************************

// ignore_for_file: cancel_subscriptions,constant_identifier_names,duplicate_import,non_constant_identifier_names,library_prefixes,UNUSED_IMPORT,UNUSED_SHOWN_NAME
import 'injector.dart';
export 'injector.dart';
import 'package:meta/meta.dart';
import 'empty.dart';
import 'hierarchical.dart';
import 'map.dart';
import 'reflective.dart';
// Required for initReflector().
import 'empty.template.dart' as _ref0;
import 'hierarchical.template.dart' as _ref1;
import 'map.template.dart' as _ref2;
import 'reflective.template.dart' as _ref3;

var _visited = false;
void initReflector() {
  if (_visited) {
    return;
  }
  _visited = true;
  _ref0.initReflector();
  _ref1.initReflector();
  _ref2.initReflector();
  _ref3.initReflector();
}

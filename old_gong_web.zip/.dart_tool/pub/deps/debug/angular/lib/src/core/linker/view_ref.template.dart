// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// Generator: TemplateGenerator
// **************************************************************************

// ignore_for_file: cancel_subscriptions,constant_identifier_names,duplicate_import,non_constant_identifier_names,library_prefixes,UNUSED_IMPORT,UNUSED_SHOWN_NAME
import 'view_ref.dart';
export 'view_ref.dart';
import 'package:angular/src/core/change_detection/constants.dart' show ChangeDetectionStrategy;
import '../change_detection/change_detector_ref.dart' show ChangeDetectorRef;
import 'app_view.dart' show AppView;
import 'app_view_utils.dart';
// Required for initReflector().
import '../change_detection/change_detector_ref.template.dart' as _ref0;
import 'app_view.template.dart' as _ref1;
import 'app_view_utils.template.dart' as _ref2;
import 'package:angular/src/core/change_detection/constants.template.dart' as _ref3;

var _visited = false;
void initReflector() {
  if (_visited) {
    return;
  }
  _visited = true;
  _ref0.initReflector();
  _ref1.initReflector();
  _ref2.initReflector();
  _ref3.initReflector();
}

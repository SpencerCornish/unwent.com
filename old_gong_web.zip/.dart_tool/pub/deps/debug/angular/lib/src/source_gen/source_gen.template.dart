// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// Generator: TemplateGenerator
// **************************************************************************

// ignore_for_file: cancel_subscriptions,constant_identifier_names,duplicate_import,non_constant_identifier_names,library_prefixes,UNUSED_IMPORT,UNUSED_SHOWN_NAME
import 'source_gen.dart';
export 'source_gen.dart';
import 'package:angular_compiler/angular_compiler.dart';
import 'package:build/build.dart';
import 'package:dart_style/dart_style.dart';
import 'package:source_gen/source_gen.dart';
import '../transform/common/names.dart';
import 'template_compiler/generator.dart';
// Required for initReflector().
import '../transform/common/names.template.dart' as _ref0;
import 'template_compiler/generator.template.dart' as _ref1;
import 'template_compiler/generator.template.dart' as _ref2;

var _visited = false;
void initReflector() {
  if (_visited) {
    return;
  }
  _visited = true;
  _ref0.initReflector();
  _ref1.initReflector();
  _ref2.initReflector();
}

/// @nodoc
library angular.source_gen;

export 'src/source_gen/source_gen.dart';

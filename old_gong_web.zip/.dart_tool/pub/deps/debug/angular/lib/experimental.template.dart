// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// Generator: TemplateGenerator
// **************************************************************************

// ignore_for_file: cancel_subscriptions,constant_identifier_names,duplicate_import,non_constant_identifier_names,library_prefixes,UNUSED_IMPORT,UNUSED_SHOWN_NAME
import 'experimental.dart';
export 'experimental.dart';
import 'package:meta/meta.dart';
import 'src/core/linker/app_view.dart' as app_view;
import 'src/core/linker/app_view_utils.dart';
import 'src/di/injector/injector.dart';
// Required for initReflector().
import 'src/core/linker/app_view.template.dart' as _ref0;
import 'src/core/linker/app_view_utils.template.dart' as _ref1;
import 'src/di/injector/injector.template.dart' as _ref2;

var _visited = false;
void initReflector() {
  if (_visited) {
    return;
  }
  _visited = true;
  _ref0.initReflector();
  _ref1.initReflector();
  _ref2.initReflector();
}

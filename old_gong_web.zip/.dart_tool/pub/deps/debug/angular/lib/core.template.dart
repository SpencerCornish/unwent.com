// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// Generator: TemplateGenerator
// **************************************************************************

// ignore_for_file: cancel_subscriptions,constant_identifier_names,duplicate_import,non_constant_identifier_names,library_prefixes,UNUSED_IMPORT,UNUSED_SHOWN_NAME
import 'core.dart';
export 'core.dart';
// Required for initReflector().
import 'src/core/angular_entrypoint.template.dart' as _ref0;
import 'src/core/application_common_providers.template.dart' as _ref1;
import 'src/core/application_ref.template.dart' as _ref2;
import 'src/core/application_tokens.template.dart' as _ref3;
import 'src/core/change_detection.template.dart' as _ref4;
import 'src/core/di.template.dart' as _ref5;
import 'src/core/linker.template.dart' as _ref6;
import 'src/core/metadata.template.dart' as _ref7;
import 'src/core/render.template.dart' as _ref8;
import 'src/core/testability/testability.template.dart' as _ref9;
import 'src/core/url_resolver.template.dart' as _ref10;
import 'src/core/zone.template.dart' as _ref11;
import 'src/facade/facade.template.dart' as _ref12;

var _visited = false;
void initReflector() {
  if (_visited) {
    return;
  }
  _visited = true;
  _ref0.initReflector();
  _ref1.initReflector();
  _ref2.initReflector();
  _ref3.initReflector();
  _ref4.initReflector();
  _ref5.initReflector();
  _ref6.initReflector();
  _ref7.initReflector();
  _ref8.initReflector();
  _ref9.initReflector();
  _ref10.initReflector();
  _ref11.initReflector();
  _ref12.initReflector();
}

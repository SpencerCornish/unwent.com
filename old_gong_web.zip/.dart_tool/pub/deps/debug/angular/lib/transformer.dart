/// @nodoc
library angular.transformer_dart;

export 'src/transform/transformer.dart';
